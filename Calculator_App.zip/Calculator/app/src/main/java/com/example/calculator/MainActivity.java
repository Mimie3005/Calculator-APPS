package com.example.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;

public class MainActivity extends AppCompatActivity {

    // UI Components for input and output
    private EditText etInvestedAmount;
    private EditText etDividendRate;
    private EditText etMonthsInvested;
    private TextView tvMonthlyDividend;
    private TextView tvTotalDividend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        initializeViews();

        // Set up the toolbar
        setupToolbar();

        // Set up button click listener
        setupClickListeners();

        // Handle system bars for modern Android
        setupWindowInsets();
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Unit Trust Calculator");
        }
    }

    private void initializeViews() {
        etInvestedAmount = findViewById(R.id.etInvestedAmount);
        etDividendRate = findViewById(R.id.etDividendRate);
        etMonthsInvested = findViewById(R.id.etMonthsInvested);
        tvMonthlyDividend = findViewById(R.id.tvMonthlyDividend);
        tvTotalDividend = findViewById(R.id.tvTotalDividend);
        Button btnCalculate = findViewById(R.id.btnCalculate);

        // Set up calculate button listener
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateDividend();
            }
        });
    }

    private void setupClickListeners() {
        // Calculate button listener is set in initializeViews()
        // This method can be extended for additional click listeners
    }

    /**
     * Handle window insets for edge-to-edge display
     */
    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void calculateDividend() {
        // Get input values from EditText fields
        String investedAmountStr = etInvestedAmount.getText().toString().trim();
        String dividendRateStr = etDividendRate.getText().toString().trim();
        String monthsInvestedStr = etMonthsInvested.getText().toString().trim();

        // Validate that all fields are filled
        if (investedAmountStr.isEmpty() || dividendRateStr.isEmpty() || monthsInvestedStr.isEmpty()) {
            showToast("Please fill in all fields");
            return;
        }

        try {
            // Parse string inputs to numeric values
            double investedAmount = Double.parseDouble(investedAmountStr);
            double dividendRate = Double.parseDouble(dividendRateStr);
            int monthsInvested = Integer.parseInt(monthsInvestedStr);

            // Validate input ranges according to assignment requirements
            if (!validateInputs(investedAmount, dividendRate, monthsInvested)) {
                return; // Error message already shown in validation method
            }

            // Perform calculations using assignment formulas
            double monthlyDividend = calculateMonthlyDividend(investedAmount, dividendRate);
            double totalDividend = calculateTotalDividend(monthlyDividend, monthsInvested);

            // Display results with proper formatting (2 decimal places)
            displayResults(monthlyDividend, totalDividend);

        } catch (NumberFormatException e) {
            showToast("Invalid number format. Please enter valid numbers.");
        }
    }

    private boolean validateInputs(double investedAmount, double dividendRate, int monthsInvested) {
        if (investedAmount <= 0) {
            showToast("Invested amount must be greater than 0");
            return false;
        }

        if (dividendRate <= 0) {
            showToast("Dividend rate must be greater than 0");
            return false;
        }

        if (monthsInvested < 1 || monthsInvested > 12) {
            showToast("Months invested must be between 1 and 12");
            return false;
        }

        return true;
    }

    private double calculateMonthlyDividend(double investedAmount, double dividendRate) {
        return (dividendRate / 100.0 / 12.0) * investedAmount;
    }

    private double calculateTotalDividend(double monthlyDividend, int monthsInvested) {
        return monthlyDividend * monthsInvested;
    }

    private void displayResults(double monthlyDividend, double totalDividend) {
        tvMonthlyDividend.setText(String.format("Monthly Dividend: RM%.2f", monthlyDividend));
        tvTotalDividend.setText(String.format("Total Dividend: RM%.2f", totalDividend));
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present
        getMenuInflater().inflate(R.menu.nav_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

         if (id == R.id.nav_about) {
            // Navigate to About page
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}