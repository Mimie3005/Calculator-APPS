package com.example.calculator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about); // Ensure this matches your About XML layout file name

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.my_toolbar); // Your toolbar ID
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("About"); // Title for this page
            getSupportActionBar().setDisplayHomeAsUpEnabled(true); // Enable the back arrow
        }

        // GitHub link click listener
        TextView githubLink = findViewById(R.id.tvGitHubLink);
        githubLink.setOnClickListener(v -> {
            String url = githubLink.getText().toString();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });
    }

    // Handle back arrow press
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Close AboutActivity and return to MainActivity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
